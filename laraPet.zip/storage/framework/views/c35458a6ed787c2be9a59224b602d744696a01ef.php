<!DOCTYPE html>
<html>

<head>
    <title>Kind Sarah || Forgot Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style type="text/css">
        @import  url(https://fonts.googleapis.com/css?family=Raleway:300,400,600);

        body {
            margin: 0;
            font-size: .9rem;
            font-weight: 400;
            line-height: 1.6;
            color: #212529;
            text-align: left;
            background-color: #f5f8fa;
        }

        .navbar-laravel {
            background-color: #f4368e;
            box-shadow: 0 2px 4px rgba(0, 0, 0, .04);
        }

        .navbar-brand,
        .nav-link,
        .my-form,
        .login-form {
            font-family: Raleway, sans-serif;
        }

        .navbar-light .navbar-brand {
            font-weight: 900;
            letter-spacing: 1.2px;
            color: white;
            transition: .5s;
            line-height: 0.8;
            font-family: 'Caveat', cursive;
            font-size: 36px;
        }

        .navbar-light .container .navbar-brand:hover {
            color: #b31d63 !important;
        }

        .my-form {
            padding-top: 1.5rem;
            padding-bottom: 1.5rem;
        }

        .my-form .row {
            margin-left: 0;
            margin-right: 0;
        }

        .login-form {
            padding-top: 1.5rem;
            padding-bottom: 1.5rem;
        }

        .login-form .row {
            margin-left: 0;
            margin-right: 0;
        }

        .btn-danger {
            background-color: #f4368e;
            font-weight: 600
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light navbar-laravel">
        <div class="container">
            <a class="navbar-brand" href="#">KindSarah</a>
            

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                

            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

</body>

</html>
<?php /**PATH /home/mh/Documents/code/chevi/laraPet/resources/views/layout.blade.php ENDPATH**/ ?>